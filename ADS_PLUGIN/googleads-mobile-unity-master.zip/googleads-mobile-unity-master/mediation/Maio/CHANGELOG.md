# maio Adapter plugin for Google Mobile Ads SDK for Unity 3D Changelog

## 1.2.3
- Updated the plugin to support the new Rewarded API.
- Supports maio Android adapter version 1.1.7.0.
- Supports maio iOS adapter version 1.4.6.0.

## 1.2.2
- Supports maio Android adapter version 1.1.6.0.
- Supports maio iOS adapter version 1.4.2.0.

## 1.2.1
- Supports maio Android adapter version 1.1.6.0.
- Supports maio iOS adapter version 1.4.1.0.

## 1.2.0
- Supports maio Android adapter version 1.1.4.1.
- Supports maio iOS adapter version 1.4.0.0.

## 1.1.3
- Supports maio Android adapter version 1.1.3.1.
- Supports maio iOS adapter version 1.3.2.0.

## 1.1.2
- Supports maio Android adapter version 1.1.3.0.
- Supports maio iOS adapter version 1.3.2.0.

## 1.1.1
- Supports maio Android adapter version 1.1.1.0.
- Supports maio iOS adapter version 1.3.1.1.

## 1.1.0
- Supports maio Android adapter version 1.1.0.0.
- Supports maio iOS adapter version 1.3.0.0.

## 1.0.2
- Supports maio Android SDK version 1.0.8.
- Supports maio iOS SDK version 1.2.19.

## 1.0.1
- Supports maio Android SDK version 1.0.7.
- Supports maio iOS SDK version 1.2.19.

## 1.0.0
- First release!
- Supports maio Android SDK version 1.0.6.
- Supports maio iOS SDK version 1.2.18.
