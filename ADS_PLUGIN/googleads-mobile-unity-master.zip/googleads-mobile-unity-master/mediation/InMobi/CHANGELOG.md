# InMobi Adapter plugin for Google Mobile Ads SDK for Unity 3D Changelog

## 2.2.2
- Updated the plugin to support the new Rewarded API.
- Supports Android adapter version 7.2.7.0.
- Supports iOS adapter version 7.2.7.0.

## 2.2.1
- Supports Android adapter version 7.2.2.0.
- Supports iOS adapter version 7.2.4.0.

## 2.2.0
- Supports Android adapter version 7.2.1.0.
- Supports iOS adapter version 7.2.0.0.

## 2.1.2
- Supports Android adapter version 7.1.1.1.
- Supports iOS adapter version 7.1.2.0.

## 2.1.1
- Supports Android adapter version 7.1.1.1.
- Supports iOS adapter version 7.1.1.2.

## 2.1.0
- Supports Android adapter version 7.1.0.0.
- Supports iOS adapter version 7.1.1.1.
- Added the `InMobi.UpdateGDPRConsent()` method.

## 2.0.0
- Supports Android adapter version 7.0.4.0.
- Supports iOS adapter version 7.1.1.0.

## 1.0.0
- First release!
- Supports Android adapter version 6.2.4.0.
- Supports iOS adapter version 6.2.1.0.
