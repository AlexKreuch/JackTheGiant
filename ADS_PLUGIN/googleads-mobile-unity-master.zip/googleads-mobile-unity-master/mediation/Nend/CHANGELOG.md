# nend Adapter plugin for Google Mobile Ads SDK for Unity 3D Changelog

## 2.1.0
- Updated the plugin to support the new Rewarded API.
- Supports nend Android adapter version 5.1.0.2.
- Supports nend iOS adapter version 5.1.1.0.

## 2.0.3
- Supports nend Android adapter version 5.0.2.1.
- Supports nend iOS adapter version 5.0.2.0.

## 2.0.2
- Supports nend Android adapter version 5.0.2.0.
- Supports nend iOS adapter version 5.0.2.0.

## 2.0.1
- Supports nend Android adapter version 5.0.2.0.
- Supports nend iOS adapter version 5.0.1.0.

## 2.0.0
- Supports nend Android adapter version 5.0.0.0.
- Supports nend iOS adapter version 5.0.0.0.

## 1.0.2
- Supports nend Android adapter version 4.0.5.0.
- Supports nend iOS adapter version 4.0.6.0.

## 1.0.1
- Supports nend Android SDK version 4.0.4.
- Supports nend iOS SDK version 4.0.4.

## 1.0.0
- First release!
- Supports nend Android SDK version 4.0.2.
- Supports nend iOS SDK version 4.0.2.
