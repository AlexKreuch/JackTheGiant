// Copyright 2018 Google Inc. All Rights Reserved.

#import <Foundation/Foundation.h>

#import <GoogleMobileAds/GoogleMobileAds.h>

#import "GADUAdNetworkExtras.h"

@interface AdColonyExtrasBuilder : NSObject<GADUAdNetworkExtras>

@end
