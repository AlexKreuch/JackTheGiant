# DU Ad Platform Adapter plugin for Google Mobile Ads SDK for Unity 3D Changelog

## 1.1.0
- Updated the plugin to support the new Rewarded API.
- Supports DU Ad Platform Android SDK version 1.2.2.
- Supports DuVideo Android SDK version 1.0.9.2.
- Supports DU Ad Platform iOS SDK version 1.1.2.

## 1.0.0
- First release!
- Supports DU Ad Platform Android SDK version 1.1.1.8.
- Supports DuVideo Android SDK version 1.0.7.2.
- Supports DU Ad Platform iOS SDK version 1.1.0.
