# IronSource Adapter plugin for Google Mobile Ads SDK for Unity 3D Changelog

## 1.1.2
- Supports IronSource Android adapter version 6.8.4.1
- Supports IronSource iOS adapter version 6.8.4.1

## 1.1.1
- Supports IronSource Android adapter version 6.8.4.1
- Supports IronSource iOS adapter version 6.8.3.0

## 1.1.0
- Updated the plugin to support the new open-beta Rewarded API.
- Supports IronSource Android adapter version 6.8.1.2
- Supports IronSource iOS adapter version 6.8.0.1

## 1.0.4
- Supports IronSource Android adapter version 6.7.11.0
- Supports IronSource iOS adapter version 6.7.11.0

## 1.0.3
- Supports IronSource Android adapter version 6.7.10.0
- Supports IronSource iOS adapter version 6.7.10.0

## 1.0.2
- Supports IronSource Android adapter version 6.7.9.1.1
- Supports IronSource iOS adapter version 6.7.10.0
- Fixed a conflict with the Chartboost Unity mediation plugin.

## 1.0.1
- Supports IronSource Android adapter version 6.7.9.0.
- Supports IronSource iOS adapter version 6.7.9.2.0.

## 1.0.0
- First release!
- Supports IronSource Android adapter version 6.7.9.0.
- Supports IronSource iOS adapter version 6.7.9.1.0.
